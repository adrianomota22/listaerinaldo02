//15. Escreva um programa que apresente um menu com as seguintes opções:
//1. Gerar a tabuada de um número.
//2. Sair.
//O programa deve solicitar ao usuário o número desejado e exibir a tabuada (de 1 a
//10). O menu deve continuar sendo exibido até que o usuário escolha a opção de
//sair.
#include <stdio.h>

int main()
{
    int n, conta, resp;
    
    printf("1 - GERAR TABUADA DE UM NUMERO\n");
    printf("2 - SAIR\n");
     scanf("%d", &resp);
     
     switch(resp) { 
      case 1:
      printf("Informe um numero: ");
       scanf("%d", &n);
       
     for(int i = 1; i <= 10; i++ ) {
        conta = n*i;
     printf("%d X %d = %d\n", n, i, conta);
     }
    break;
     case 2:printf("saindo.");
      return 0;
    break;
    default:printf("opção invalida.");
     main();
    }
    return 0;
}    