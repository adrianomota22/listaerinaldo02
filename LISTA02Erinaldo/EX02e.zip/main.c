//2. Um número perfeito é aquele que é igual à soma de seus divisores próprios
//(excluindo ele mesmo). Escreva um programa que solicite ao usuário um número
//inteiro positivo e verifique se esse número é perfeito. O programa deve utilizar um
//laço para somar os divisores e, no final, informar se o número é perfeito ou não. (0.1
//ponto)
//Entradas: número inteiro positivo.
//Saída: informar se o número é perfeito ou não.

#include <stdio.h>

int main(void) {
int n, soma = 0, i; 

printf("informe um numero inteiro:");
 scanf("%d", &n);  
  
  if (n <= 0 ) {
  printf("INFORME UM NUMERO INTEIRO POSITIVO VALIDO."); 
  }
  for (i = 1; i <= n/2; i++) {
    if (n % i == 0) {
      soma += i;
    }
  }
   if (soma == n) {
   printf("%d é numero perfeito.\n", n);
   } else {
   printf("%d não é um numero perfeito.\n", n);
   }  


return 0; 
}