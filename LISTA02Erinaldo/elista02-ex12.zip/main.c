//12. Escreva um programa que solicite ao usuário 6 números inteiros. Para cada
//número, verifique se ele é par ou ímpar. Se o número for par, verifique se é maior
//que 10 ou não. Se for ímpar, verifique se é menor que 50 ou não


#include <stdio.h>

int main() {
    int numeros[6];  // Array para armazenar os 6 números
    int i;

    // Solicita os números ao usuário
    for(i = 0; i < 6; i++) {
        printf("Digite o %dº número inteiro: ", i + 1);
        scanf("%d", &numeros[i]);
    }

    // Verifica cada número
    for(i = 0; i < 6; i++) {
        if (numeros[i] % 2 == 0) {  // Verifica se o número é par
            printf("O número %d é par ", numeros[i]);
            if (numeros[i] > 10) {
                printf("e maior que 10.\n");
            } else {
                printf("e menor ou igual a 10.\n");
            }
        } else {  // Caso o número seja ímpar
            printf("O número %d é ímpar ", numeros[i]);
            if (numeros[i] < 50) {
                printf("e menor que 50.\n");
            } else {
                printf("e maior ou igual a 50.\n");
            }
        }
    }

    return 0;
}

