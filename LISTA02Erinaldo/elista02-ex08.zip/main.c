//8. Escreva um programa que sorteie um número entre 1 e 100 e permita ao usuário
//tentar adivinhar o número. O programa deve dar dicas se o número sorteado é
//maior ou menor que o palpite do usuário. O usuário tem no máximo 7 tentativas
//para acertar. No final, informe se o usuário acertou ou não. 

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int numero_secreto, palpite, tentativas = 7;

    
    srand(time(NULL));
    numero_secreto = rand() % 100 + 1;  

    printf("Bem-vindo ao jogo de adivinhar o número!\n");
    printf("Tente adivinhar o número entre 1 e 100. Você tem %d tentativas.\n", tentativas);

    for (int i = 1; i <= tentativas; i++) {
        printf("\nTentativa %d: ", i);
        scanf("%d", &palpite);

        if (palpite < 1 || palpite > 100) {
            printf("Por favor, insira um número entre 1 e 100.\n");
            i--; 
            continue;
        }

        if (palpite == numero_secreto) {
            printf("Parabéns! Você acertou o número em %d tentativas!\n", i);
            return 0;
        } else if (palpite < numero_secreto) {
            printf("O número sorteado é maior!\n");
        } else {
            printf("O número sorteado é menor!\n");
        }
    }

    printf("\nVocê não conseguiu adivinhar o número. O número era: %d\n", numero_secreto);

    return 0;
}
