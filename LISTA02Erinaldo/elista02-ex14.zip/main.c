//14. Escreva um programa que apresente um menu com as seguintes opções:
//1. Adição.
//2. Subtração.
//3. Multiplicação.
//4. Divisão.
//5. Sair.
//O programa deve solicitar dois números e realizar a operação escolhida. Deve
//continuar exibindo o menu até que o usuário escolha a opção de sair

#include <stdio.h>

int main() {
    int opcao;
    float num1, num2, resultado;

    do {
        // Exibe o menu
        printf("\n MENU \n");
        printf("1 - Adição\n");
        printf("2 - Subtração\n");
        printf("3 - Multiplicação\n");
        printf("4 - Divisão\n");
        printf("5 - Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        // Se o usuário escolher sair, interrompe o loop
        if (opcao == 5) {
            printf("Saindo.\n");
            break;
        }

        // Solicita os números
        printf("Digite o primeiro número: ");
        scanf("%f", &num1);
        printf("Digite o segundo número: ");
        scanf("%f", &num2);

        // Realiza a operação escolhida
        switch(opcao) {
            case 1:
                resultado = num1 + num2;
                printf("Resultado da adição: %.2f\n", resultado);
                break;
            case 2:
                resultado = num1 - num2;
                printf("Resultado da subtração: %.2f\n", resultado);
                break;
            case 3:
                resultado = num1 * num2;
                printf("Resultado da multiplicação: %.2f\n", resultado);
                break;
            case 4:
                // Verifica se o divisor não é zero
                if (num2 != 0) {
                    resultado = num1 / num2;
                    printf("Resultado da divisão: %.2f\n", resultado);
                } else {
                    printf("Erro: Divisão por zero não é permitida.\n");
                }
                break;
            default:
                printf("Opção inválida. Por favor, tente novamente.\n");
        }

    } while(opcao != 5);  // Continua até que o usuário escolha sair

    return 0;
}
