//1. Escreva um programa em C que solicite ao usuário o valor inicial de um
//investimento, a taxa de juros anual (em porcentagem) e o número de anos que o
//dinheiro será investido. O programa deve calcular o valor final do investimento ao
//final de cada ano, aplicando os juros compostos, e mostrar uma tabela com o valor
//acumulado ano a ano. 

#include <stdio.h>

int main(void) {
 
  double v_inicial, juros, v_final;
 int i, ano;

 printf("informe o valor incial de seu investimento:");
  scanf("%f", &v_inicial);
 printf("informe a taxa de juros anual(em porcentagem):");
  scanf("%f", &juros);
 printf("informe quantos anos o dinheiro sera investido:");
  scanf("%d", &ano);

  juros = juros/100;
  v_final = v_inicial; 
  
  printf("VALOR ACUMULADO\n");
  for (i = 1; i <= ano; i++) {

    v_final = v_final + (v_final * juros);
    
  printf("%d\n%.2f\n", i, v_final);
  } 
}