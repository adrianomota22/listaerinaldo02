//6. Escreva um programa que solicite dois números inteiros positivos ao usuário: um
//valor inicial e um valor final. O programa deve então exibir todos os números primos
//dentro desse intervalo. Se não houver números primos no intervalo, o programa
//deve informar isso.

#include <stdio.h>

int ehPrimo(int num) {
    if (num < 2) {
        return 0;  
    }
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            return 0;  
        }
    }
    return 1;  
}

int main() {
    int valorInicial, valorFinal;
    int encontrouPrimo = 0;

    printf("Insira o valor inicial: ");
    scanf("%d", &valorInicial);
    printf("Insira o valor final: ");
    scanf("%d", &valorFinal);

    if (valorInicial < 0 || valorFinal < 0 || valorInicial > valorFinal) {
        printf("Os valores devem ser positivos, e o valor inicial deve ser menor ou igual ao valor final.\n");
        return 1;
    }

    printf("Numeros primos entre %d e %d:\n", valorInicial, valorFinal);

    for (int i = valorInicial; i <= valorFinal; i++) {
        if (ehPrimo(i)) {
            printf("%d ", i);
            encontrouPrimo = 1;
        }
    }

    if (!encontrouPrimo) {
        printf("Nao ha numeros primos nesse intervalo.\n");
    }

    return 0;
}
