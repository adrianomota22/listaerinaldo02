//11. Escreva um programa que peça ao usuário para inserir as notas de 8 alunos e
//classifique cada nota em conceitos: A (nota entre 9 e 10), B (nota entre 7 e 8.9), C
//(nota entre 5 e 6.9), D (nota entre 3 e 4.9) ou F (nota abaixo de 3)

#include <stdio.h>

int main() {
    float notas[8];  // Array para armazenar as notas dos 8 alunos
    char conceito;    // Variável para armazenar o conceito
    int i;

    // Pedir ao usuário para inserir as notas dos 8 alunos
    for(i = 0; i < 8; i++) {
        printf("Digite a nota do aluno %d: ", i + 1);
        scanf("%f", &notas[i]);
    }

    printf("\nClassificação de cada aluno:\n");

    // Classificar cada nota em conceitos
    for(i = 0; i < 8; i++) {
        if (notas[i] >= 9 && notas[i] <= 10) {
            conceito = 'A';
        } else if (notas[i] >= 7 && notas[i] < 9) {
            conceito = 'B';
        } else if (notas[i] >= 5 && notas[i] < 7) {
            conceito = 'C';
        } else if (notas[i] >= 3 && notas[i] < 5) {
            conceito = 'D';
        } else if (notas[i] < 3) {
            conceito = 'F';
        } else {
            printf("Nota inválida para o aluno %d.\n", i + 1);
            continue;  // Pular para o próximo aluno em caso de nota inválida
        }

        // Exibir a nota e o conceito correspondente
        printf("Aluno %d - Nota: %.2f - Conceito: %c\n", i + 1, notas[i], conceito);
    }

    return 0;
}


