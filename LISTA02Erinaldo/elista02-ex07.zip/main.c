//7. Crie um programa que peça ao usuário para inserir as notas de 5 alunos. Para
//cada aluno, o programa deve calcular a média. Se a média for maior ou igual a 7.0,
//o aluno é aprovado; caso contrário, ele é reprovado. Ao final, o programa deve exibir
//a média de cada aluno e se ele foi aprovado ou reprovado.

#include <stdio.h>

int main() {
    float notas[5][3];  
    float media[5];     
    int i, j;

    // Solicita as notas dos alunos
    for (i = 0; i < 5; i++) {
        printf("Digite as 3 notas do aluno %d:\n", i + 1);
        for (j = 0; j < 3; j++) {
            printf("Nota %d: ", j + 1);
            scanf("%f", &notas[i][j]);
        }
    }

    for (i = 0; i < 5; i++) {
        media[i] = (notas[i][0] + notas[i][1] + notas[i][2]) / 3;
        printf("Aluno %d: Média = %.2f - ", i + 1, media[i]);
        if (media[i] >= 7.0) {
            printf("Aprovado\n");
        } else {
            printf("Reprovado\n");
        }
    }

    return 0;
}

