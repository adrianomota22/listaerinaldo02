//9. Escreva um programa que peça ao usuário para inserir as notas de 5 alunos.
//Para cada aluno, o programa deve calcular a média de duas provas. Se a média for
//maior ou igual a 7.0, o aluno é aprovado. Se a média estiver entre 5.0 e 6.9, o aluno
//vai para a recuperação, e se for menor que 5.0, o aluno é reprovado

#include <stdio.h>

int main() {
    float nota1, nota2, media;
    int i;

    
    for (i = 1; i <= 5; i++) {
        printf("Aluno %d:\n", i);

        // Receber as notas das duas provas
        printf("Digite a nota da primeira prova: ");
        scanf("%f", &nota1);
        printf("Digite a nota da segunda prova: ");
        scanf("%f", &nota2);

    
        media = (nota1 + nota2) / 2;

        
        if (media >= 7.0) {
            printf("Aluno %d aprovado com media %.2f.\n", i, media);
        } else if (media >= 5.0) {
            printf("Aluno %d em recuperação com media %.2f.\n", i, media);
        } else {
            printf("Aluno %d reprovado com media %.2f.\n", i, media);
        }

        printf("\n"); 
    }

    return 0;
}
