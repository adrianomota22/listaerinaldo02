//5. Escreva um programa que peC'a ao usuC!rio para inserir 10 nC:meros inteiros. O
//programa deve contar quantos nC:meros sC#o pares e quantos sC#o C-mpares, e exibir
//esses valores no final.

#include <stdio.h>

int main() {
    int numeros[10]; 
    int pares = 0, impares = 0;

    
    printf("Informe 10 numeros inteiros:\n");
    for (int i = 0; i < 10; i++) { 
        printf("Numero %d: ", i + 1);
        scanf("%d", &numeros[i]);


        if (numeros[i] % 2 == 0) {
            pares++;
        } else {
            impares++;
        }
    }
    printf("\nTotal de numeros pares: %d\n", pares);
    printf("Total de numeros impares: %d\n", impares);

    return 0;
}
